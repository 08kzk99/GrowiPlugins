var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState } from 'react';
/**
 * Component to render images with size adjustment capabilities
 */
export var ImageWithSize = function (props) {
    var src = props.src, alt = props.alt, width = props.width, height = props.height, style = props.style, rest = __rest(props, ["src", "alt", "width", "height", "style"]);
    var _a = useState(false), isModalOpen = _a[0], setIsModalOpen = _a[1];
    var _b = useState({ width: width, height: height }), imageSize = _b[0], setImageSize = _b[1];
    var combinedStyle = __assign(__assign(__assign({}, style), (imageSize.width && { width: typeof imageSize.width === 'number' ? "".concat(imageSize.width, "px") : imageSize.width })), (imageSize.height && { height: typeof imageSize.height === 'number' ? "".concat(imageSize.height, "px") : imageSize.height }));
    var toggleModal = function () {
        setIsModalOpen(!isModalOpen);
    };
    var handleSizeChange = function (newSize) {
        setImageSize(__assign(__assign({}, imageSize), newSize));
        setIsModalOpen(false);
    };
    return (_jsxs(_Fragment, { children: [_jsx("img", __assign({ src: src, alt: alt || '', style: combinedStyle, onDoubleClick: toggleModal }, rest)), isModalOpen && (_jsx("div", { style: {
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    zIndex: 1000,
                }, onClick: function () { return setIsModalOpen(false); }, children: _jsxs("div", { style: {
                        backgroundColor: 'white',
                        padding: '20px',
                        borderRadius: '5px',
                        maxWidth: '400px',
                        width: '100%',
                    }, onClick: function (e) { return e.stopPropagation(); }, children: [_jsx("h3", { style: { marginTop: 0 }, children: "\u753B\u50CF\u30B5\u30A4\u30BA\u8ABF\u6574" }), _jsxs("div", { style: { marginBottom: '10px' }, children: [_jsx("label", { style: { display: 'block', marginBottom: '5px' }, children: "\u5E45:" }), _jsx("input", { type: "text", value: imageSize.width || '', onChange: function (e) { return setImageSize(__assign(__assign({}, imageSize), { width: e.target.value })); }, style: { width: '100%', padding: '5px' }, placeholder: "\u4F8B: 300px, 50%, auto" })] }), _jsxs("div", { style: { marginBottom: '20px' }, children: [_jsx("label", { style: { display: 'block', marginBottom: '5px' }, children: "\u9AD8\u3055:" }), _jsx("input", { type: "text", value: imageSize.height || '', onChange: function (e) { return setImageSize(__assign(__assign({}, imageSize), { height: e.target.value })); }, style: { width: '100%', padding: '5px' }, placeholder: "\u4F8B: 200px, auto" })] }), _jsxs("div", { style: { display: 'flex', justifyContent: 'space-between' }, children: [_jsx("button", { onClick: function () { return setIsModalOpen(false); }, style: {
                                        padding: '8px 16px',
                                        backgroundColor: '#f1f1f1',
                                        border: 'none',
                                        borderRadius: '4px',
                                        cursor: 'pointer',
                                    }, children: "\u30AD\u30E3\u30F3\u30BB\u30EB" }), _jsx("button", { onClick: function () { return handleSizeChange(imageSize); }, style: {
                                        padding: '8px 16px',
                                        backgroundColor: '#4285f4',
                                        color: 'white',
                                        border: 'none',
                                        borderRadius: '4px',
                                        cursor: 'pointer',
                                    }, children: "\u9069\u7528" })] })] }) }))] }));
};
