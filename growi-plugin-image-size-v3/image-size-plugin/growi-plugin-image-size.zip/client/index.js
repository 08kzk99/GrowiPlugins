import { ImageWithSize } from './components/ImageWithSize';
export var activate = function (growi) {
    if (growi.markdownRenderer && growi.markdownRenderer.optionsGenerators) {
        var originalGenerateViewOptions_1 = growi.markdownRenderer.optionsGenerators.generateViewOptions;
        growi.markdownRenderer.optionsGenerators.generateViewOptions = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var options = originalGenerateViewOptions_1.apply(void 0, args);
            if (options.components) {
                options.components.img = ImageWithSize;
            }
            return options;
        };
        var originalGeneratePreviewOptions_1 = growi.markdownRenderer.optionsGenerators.generatePreviewOptions;
        growi.markdownRenderer.optionsGenerators.generatePreviewOptions = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var options = originalGeneratePreviewOptions_1.apply(void 0, args);
            if (options.components) {
                options.components.img = ImageWithSize;
            }
            return options;
        };
    }
};
