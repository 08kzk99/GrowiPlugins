import React from 'react';
type ImageWithSizeProps = React.DetailedHTMLProps<React.ImgHTMLAttributes<HTMLImageElement>, HTMLImageElement>;
/**
 * Component to render images with size adjustment capabilities
 */
export declare const ImageWithSize: React.FC<ImageWithSizeProps>;
export {};
