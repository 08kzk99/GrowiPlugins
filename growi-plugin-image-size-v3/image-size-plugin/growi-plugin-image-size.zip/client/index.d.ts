export declare const activate: (growi: any) => void;
